package SyntaxError;
use strict;
use warnings;

# this syntax error is intentional!

    {

1;
