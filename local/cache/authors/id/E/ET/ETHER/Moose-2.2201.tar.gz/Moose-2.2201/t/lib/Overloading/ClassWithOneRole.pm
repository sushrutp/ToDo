package Overloading::ClassWithOneRole;

use Moose;

with 'Overloading::RoleWithOverloads';

1;
