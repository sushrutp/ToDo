package Dancer2::Plugin::Null;
use Dancer2::Plugin;
register_plugin;
1;
