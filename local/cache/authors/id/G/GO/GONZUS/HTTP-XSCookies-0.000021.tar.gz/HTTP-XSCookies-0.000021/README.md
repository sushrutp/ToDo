Quick & dirty cookie mangling for Perl
